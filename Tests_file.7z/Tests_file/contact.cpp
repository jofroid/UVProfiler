#include "Contact.h"

#include <iostream>


Contact::SiteWeb::SiteWeb (const QString Nom, const QUrl Adr)
{
    name = Nom;
    adresse = Adr;
}


Contact::Contact (const quint16 NumeroMaison,
                    const QString Adresse,
                    const QString Nom,
                    const QDate Aniv,
                    const SiteWebList Sites)
    :	m_numeroMaison(NumeroMaison),
        m_adresse(Adresse),
        m_nom(Nom),
        m_aniv(Aniv),
        m_sites(Sites)
{}
Contact::Contact (const Contact & Copie)
{
    m_numeroMaison = Copie.m_numeroMaison;
    m_adresse = Copie.m_adresse;
    m_nom = Copie.m_nom;
    m_aniv = Copie.m_aniv;
    m_sites = Copie.m_sites;
}
Contact::~Contact()
{}

void Contact::afficher () const
{
    std::cout	<< "Le contact "
                << m_nom.toStdString()
                << " nee le "
                << m_aniv.day() << "/" << m_aniv.month() << "/" << m_aniv.year()
                << " et qui loge au "
                << static_cast<int>(m_numeroMaison) << " " << m_adresse.toStdString()
                << " possede les sites webs suivant : ";

    SiteWeb curr;
    foreach(curr, m_sites)
        std::cout << curr.name.toStdString() << ":" << curr.adresse.toString().toStdString() << " - ";

    std::cout << std::endl;
}


void Contact::initContactSystem ()
{
    qRegisterMetaTypeStreamOperators<Contact::SiteWeb>("Contact::SiteWeb");
    qRegisterMetaTypeStreamOperators<Contact>("Contact");

    qMetaTypeId<Contact::SiteWeb>();	// Teste la validité de la structure SiteWeb
    qMetaTypeId<Contact>();				// Teste la validité de la classe Contact
}

QDataStream & operator << (QDataStream & out, const Contact::SiteWeb & Valeur)
{
    out << Valeur.name
        << Valeur.adresse;

    return out;
}
QDataStream & operator >> (QDataStream & in, Contact::SiteWeb & Valeur)
{
    in >> Valeur.name;
    in >> Valeur.adresse;

    return in;
}

QDataStream & operator << (QDataStream & out, const Contact & Valeur)
{
    out << Valeur.m_numeroMaison
        << Valeur.m_adresse
        << Valeur.m_nom
        << Valeur.m_aniv
        << Valeur.m_sites;

    return out;
}
QDataStream & operator >> (QDataStream & in, Contact & Valeur)
{
    in >> Valeur.m_numeroMaison;
    in >> Valeur.m_adresse;
    in >> Valeur.m_nom;
    in >> Valeur.m_aniv;
    in >> Valeur.m_sites;

    return in;
}

