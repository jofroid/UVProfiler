#ifndef CONTACT_H
#define CONTACT_H

    #include <QVariant>

    #include <QUrl>
    #include <QString>
    #include <QList>
    #include <QDate>

    class Contact		// Représentation d'un Contact
    {
        public:
            struct SiteWeb
            {
                SiteWeb (const QString Nom = "", const QUrl Adr = QString());

                QString name;
                QUrl adresse;
            };
            typedef QList<SiteWeb> SiteWebList;

            Contact (const quint16 NumeroMaison = 0,
                        const QString Adresse = "",
                        const QString Nom = "",
                        const QDate Aniv = QDate(),
                        const SiteWebList Sites = SiteWebList());	// Constructeur par défaut public
            Contact (const Contact & Copie);						// Constructeur de copie public
            ~Contact ();											// Destructeur public

            void afficher () const;									// Affiche les informations du contact dans la console

            static void initContactSystem ();

        private:
            quint16 m_numeroMaison;		// Le n° de la maison
            QString m_adresse;			// L'adresse (sans le n°)
            QString m_nom;				// Le nom
            QDate m_aniv;				// La date d'anniversaire

            SiteWebList m_sites;		// La liste des sites webs

            /* Les opérateurs de flux sont des fonctions amies */
            friend QDataStream & operator << (QDataStream &, const Contact::SiteWeb &);
            friend QDataStream & operator >> (QDataStream &, Contact::SiteWeb &);

            friend QDataStream & operator << (QDataStream &, const Contact &);
            friend QDataStream & operator >> (QDataStream &, Contact &);
    };

    Q_DECLARE_METATYPE(Contact::SiteWeb)
    QDataStream & operator << (QDataStream & out, const Contact::SiteWeb & Valeur);
    QDataStream & operator >> (QDataStream & in, Contact::SiteWeb & Valeur);

    Q_DECLARE_METATYPE(Contact)
    QDataStream & operator << (QDataStream & out, const Contact & Valeur);
    QDataStream & operator >> (QDataStream & in, Contact & Valeur);

#endif

