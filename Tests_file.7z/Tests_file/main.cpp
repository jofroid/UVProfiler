#include "enscredits.h"

#include <QFile>
#include <QSettings>
#include <iostream>

int main()
{
    EnsCredits::initEnsCreditsSystem();
    QFile::remove("Test.ini");

    EnsCredits test(0, 1, 0, 4), test2(4,2,1,0), test3, test4(2,0,1);

    QSettings fichier_ecrire("Test.ini", QSettings::IniFormat);
    fichier_ecrire.beginGroup("test");
    fichier_ecrire.setValue("test1", QVariant::fromValue(test));
    fichier_ecrire.setValue("test2", QVariant::fromValue(test2));
    fichier_ecrire.setValue("test3", QVariant::fromValue(test3));
    fichier_ecrire.setValue("test4", QVariant::fromValue(test4));
    fichier_ecrire.endGroup();
    fichier_ecrire.sync();

    EnsCredits test_lu;
    QSettings fichier_lire("Test.ini", QSettings::IniFormat);
    /*test_lu = fichier_lire.value("test1", QVariant::fromValue(EnsCredits() )).value<EnsCredits>();
    test_lu.afficheEnsCredits();
    std::cout<<"\ntest2:\n";
    test_lu = fichier_lire.value("test2", QVariant::fromValue(EnsCredits() )).value<EnsCredits>();
    test_lu.afficheEnsCredits();
    std::cout<<"\ntest3:\n";
    test_lu = fichier_lire.value("EnsCredits", QVariant::fromValue(EnsCredits() )).value<EnsCredits>();
    test_lu.afficheEnsCredits();
    std::cout<<"\ntest4:\n";
    test_lu = fichier_lire.value("EnsCredits", QVariant::fromValue(EnsCredits() )).value<EnsCredits>();
    test_lu.afficheEnsCredits(); //*/

    fichier_lire.beginGroup("test");
    const QStringList childKeys = fichier_lire.childKeys();
    foreach (const QString& childKey, childKeys) {
        std::cout<<childKey.toStdString()<<std::endl;
        fichier_lire.value(childKey, QVariant::fromValue(EnsCredits() )).value<EnsCredits>().afficheEnsCredits();
    }
    fichier_lire.endGroup(); //*/

    return 0;
}
